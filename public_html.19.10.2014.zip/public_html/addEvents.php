<!-- File: addEvents.php
 * ------------------------
 * This php file will be concerned with gathering the details of a new event
 * and then submitting that information to the newEventProcess php file. This page will
 * display specific fields where the user can specify details about the event.
 -->
 
<html>
<head>

<link rel="stylesheet" type="text/css" href="buttons.css">
<link rel="stylesheet" type="text/css" href="form.css">
</head>
<body>

<div id="header">
</div>
<div class="navAlign" id="container">
<ul class="navButton">

<li><a href="dashboard.php">Dashboard</a></li>
<li id="current"><a href="viewEvents.php">Events</a></li>
<li><a href = "viewVolunteers.php">Volunteers</a></li>
<li><a href = "viewActivities.php">Activities</a></li>
<li><a href = "viewRoles.php">Roles</a></li>

</ul>
</div>


<div class="content" id="container">


<!--Send the form for processing to the newEventProcess php file-->

<p id="pAlign">
Testing 123 hello
</p>
<form action="newEventProcess.php" method="post" class="createUser" >
<!--Volunteer fields that the user must fill in-->

<?php
//Defines the constants along with its values
define('DB_NAME', 'group14x_database'); //name of database
define('DB_USER', 'group14x'); //name of database user
define('DB_PW', 'wearethebest'); //password
define('DB_HOST', 'localhost'); //where the database is running
?>

<h1>Event Creation Form</h1>
<label>
<span>Event ID</span>
<input id="Event_ID" type="text" name="Event_ID" maxlength="8" />
</label>

<label>
<span>Name</span>
<input id="Name" type="text" name="Name" />
</label>

<label>
<span>Description</span>
<textarea id="Description" name="Description" rows=5 cols=25></textarea>
</label>

<label>
<span>Start Date</span>
<input id="Start_Date" type="Date" name="Start_Date" />
</label>

<label>
<span>End Date</span>
<input id="End_Date" type="Date" name="End_Date" />
</label>


<label>
<span>Location</span>
<input id="Location" type="text" name="Location" />
</label>

<?php

//a variable created based on the connection to the sql database
$dbLink = mysql_connect(DB_HOST,DB_USER, DB_PW);
mysql_select_db(DB_NAME,$dbLink); 

$volunteersList = mysql_query("SELECT * FROM `Account` INNER JOIN `User Details` 
ON Account.UTS_ID = `User Details`.User_ID  
WHERE Account.Privilege IN(2,3)  
ORDER BY `User Details`.Given_Names");

?>
<label>
<span> Manager </span>
<select id="volunteer_list" name="volunteer_list" style="width: 200px;">
<?php
$i=0;

while($row = mysql_fetch_array($volunteersList)) { //loops until the end of the volunteers list, which should return a false
?>
<!--Displays the list of  options within the html page-->
<option value=<?=$row["User_ID"];?>><?=$row["Given_Names"] . " " . $row["Surname"] ;?></option>
<?php
$i++;
}

?>
</select>
<?php
mysql_close($dbLink); //closes the connection to the database
?>
</label>

<label>
<span> &nbsp</span>
<input type="submit" class="button" value="Submit" />
</label>
 
 </form>
</div>

</body>
</html>