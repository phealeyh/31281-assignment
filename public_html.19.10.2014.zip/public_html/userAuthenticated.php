<?php
session_start();
?>
<html>
<?php
// Redirect if not login unsuccessful pattern sourced from 
// - http://www.phpeasystep.com/phptu/6.html

if ( $_SESSION['LoggedIn'] == 101 ){
//Defines the constants along with its values
define('DB_NAME', 'group14x_database'); //name of database
define('DB_USER', 'group14x'); //name of database user
define('DB_PW', 'wearethebest'); //password
define('DB_HOST', 'localhost'); //where the database is running

//a variable created based on the connection to the sql database
$dbLink = mysql_connect(DB_HOST,DB_USER, DB_PW);
$selectedDB = mysql_select_db(DB_NAME,$dbLink); 

$currentUser = $_SESSION['UserID'];
$get_SQL=mysql_query("SELECT * FROM `User Details`
WHERE User_ID = $currentUser");

$row = mysql_fetch_array($get_SQL);
$Given_Names = $row['Given_Names'];
$Surname = $row['Surname'];

$loggedInAs = $Given_Names . " " . $Surname;

$_SESSION['Name'] = $loggedInAs;

echo '<script type="text/javascript">
           window.location = "viewEvents.php"
      </script>';
      
echo '<body>
 Login Successful!!!
 </body>';
      
} else {

echo "<body>
 isset failed.
</body>";

}
?>
</html>