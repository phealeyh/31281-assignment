<!-- File: viewActivites.php
 * ------------------------
 * This html file contains the list of activities within the system.
 * It is also responsible for establishing the connection between the database and requesting
 * queries about the list of events. It displays the activites in a drop down box.
 -->
<html>
<head>

<link rel="stylesheet" type="text/css" href="buttons.css">
</head>
<body>

<div id="header">
</div>

<div class="navAlign" id="container">
<ul class="navButton">

<li><a href="dashboard.php">Dashboard</a></li>
<li><a href="viewEvents.php">Events</a></li>
<li><a href = "viewVolunteers.php">Volunteers</a></li>
<li id="current"><a href = "viewActivities.php">Activities</a></li>
<li><a href = "viewRoles.php">Roles</a></li>


</ul>
</div>

<div class="content" id="container">
<h2> Activities: </h2>
<!-- Allows a specific event to be editted -->
<form action="updateActivity.php" method="post"> 
<?php
//Defines the constants along with its values
define('DB_NAME', 'group14x_database'); //name of database
define('DB_USER', 'group14x'); //name of database user
define('DB_PW', 'wearethebest'); //password
define('DB_HOST', 'localhost'); //where the database is running

//a variable created based on the connection to the sql database
$dbLink = mysql_connect(DB_HOST,DB_USER, DB_PW);
mysql_select_db(DB_NAME,$dbLink); 
$activitiesList = mysql_query("SELECT * FROM `Activities` ORDER BY Name");
?>
<select id="activity_list" name="activity_list" style="width: 400px;">
<?php
$i=0;

while($row = mysql_fetch_array($activitiesList)) { //loops until the end of the volunteers list, which should return a false
?>
<!--Displays the list of  options within the html page-->
<option value=<?=$row["Activity_ID"];?>><?=$row["Name"] ;?></option>
<?php
$i++;
}

?>
</select>
<?php
mysql_close($dbLink); //closes the connection to the database
?>

<input type="submit" value="Update"> 
</form>
<p><br><br><br><br><br><br><br><br></p>

<form action="addActivities.php" method="post"> <!-- Specifies where to send the form data -->
<input type="submit" value="Add New Activity"> <!--creates the add activity button-->
</form>

</div>

</body>
</html>