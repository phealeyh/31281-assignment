<?php
session_start();
if (!$_SESSION['LoggedIn'] == 101) {
    header("Location: index.php");
} 
?>
<!-- File: viewRoles.php
 * ------------------------
 * This html file contains the list of roles within the system.
 * It is also responsible for establishing the connection between the database and requesting
 * queries about the list of events. It displays the roles in a drop down box.
 -->
<html>
<head>

<link rel="stylesheet" type="text/css" href="buttons.css">
</head>
<body>

<div id="header">
</div>
<div class="navAlign" id="container">
<ul class="navButton">

<li><a href="dashboard.php">Dashboard</a></li>
<li><a href="viewEvents.php">Events</a></li>
<li><a href = "viewVolunteers.php">Volunteers</a></li>
<li><a href = "viewActivities.php">Activities</a></li>
<li id="current"><a href = "viewRoles.php">Roles</a></li>


</ul>
</div>

<div class="content" id="container">

<h2> Roles: </h2>

<!-- Allows a specific role to be editted -->
<form action="updateRole.php" method="post"> 
<?php
//Defines the constants along with its values
define('DB_NAME', 's1053775_database'); //name of database
define('DB_USER', 's1053775_root'); //name of database user
define('DB_PW', 'W3arethebest'); //password
define('DB_HOST', 'localhost'); //where the database is running

//a variable created based on the connection to the sql database
$dbLink = mysql_connect(DB_HOST,DB_USER, DB_PW);
mysql_select_db(DB_NAME,$dbLink); 
$rolesList = mysql_query("SELECT * FROM `Role` ORDER BY Role_Name");
?>
<select id="role_list" name="role_list" style="width: 400px;">
<?php
$i=0;

while($row = mysql_fetch_array($rolesList)) { //loops until the end of the volunteers list, which should return a false
?>
<!--Displays the list of  options within the html page-->
<option value=<?=$row["Role_ID"];?>><?=$row["Role_Name"] ;?></option>
<?php
$i++;
}

?>
</select>
<?php
mysql_close($dbLink); //closes the connection to the database
?>

<input type="submit" value="Update"> 
</form>
<p><br><br><br><br><br><br><br><br><br></p>

<form action="addRoles.php" method="post"> <!-- Specifies where to send the form data -->
<input type="submit" value="Add New Role"> <!--creates the add activity button-->
</form>

</div>

</body>
</html>