<?php

session_start();
if ($_SESSION['LoggedIn'] != $_SESSION['AdminCode'] && $_SESSION['LoggedIn'] !=$_SESSION['EMCode']) {
    header("Location: index.php");
}

?>
<!-- File: viewEvents.php
 * ------------------------
 * This html file contains the list of events within the system.
 * It is also responsible for establishing the connection between the database and requesting
 * queries about the list of events. It displays the events in a drop down box.
 -->
<html>
<head>

<link rel="stylesheet" type="text/css" href="buttons.css">
</head>
<body>

<?php

?>

<div id="header">
<?php $currentUser = $_SESSION['Name']; ?>
Logged in as: <b><?php echo $currentUser; ?></b>            <a href="logout.php"> Log Out </a>
</div>

<div class="navAlign" id="container">
<?php echo $_SESSION['Navigation']; ?>

</div>

<div class="content" id="container">

<h2>All Events</h2>



<!-- Allows a specific event to be editted -->
<form action="manageEvent.php" method="post" id="dropdown"> 
<?php


//Defines the constants along with its values
define('DB_NAME', 'group14x_database'); //name of database
define('DB_USER', 'group14x'); //name of database user
define('DB_PW', 'wearethebest'); //password
define('DB_HOST', 'localhost'); //where the database is running

//a variable created based on the connection to the sql database
$dbLink = mysql_connect(DB_HOST,DB_USER, DB_PW);
mysql_select_db(DB_NAME,$dbLink); 
$eventsList = mysql_query("SELECT * FROM `Event` ORDER BY Name");
?>

<?php
//<select id="event_list" name="event_list" style="width: 400px;">
$i=0;
// 
echo "<table border='1' class=\"table1\" id='container' >
<tr>
<th>Select</th>
<th>Event ID</th>
<th>Event Name</th>
<th>Start Date</th>
<th>End Date</th>
</tr>";
//loop starts here

while($row = mysql_fetch_array($eventsList)) { //loops until the end of the volunteers 


  echo "<tr>";
  echo "<td><input type=\"radio\" name=\"event_list\" value=".$row['Event_ID']."></td>";
  echo "<td>" . $row['Event_ID'] . "</td>";
  echo "<td>" . $row['Name'] . "</td>";
  echo "<td>" . $row['Start_Date'] . "</td>";
  echo "<td>" . $row['End_Date'] . "</td>";
  echo "</tr>";
  
$i++;
}

// while($row = mysql_fetch_array($eventsList)) { //loops until the end of the volunteers list, which should return a false
// ?>
// <!--Displays the list of  options within the html page-->
// <option value=<?=$row["Event_ID"];?>><?=$row["Name"] ;?></option>
// <?php




//loop ends here






mysql_close($dbLink); //closes the connection to the database
?>

<input type="submit" value="Manage"> 
</form>


<p><br><br><br><br></p>

<form action="addEvents.php" method="post" id="dropdown"> <!-- Specifies where to send the form data -->
<input type="submit" value="Add New Event"> <!--creates the add event button-->
</form>





</div>


</body>
</html>