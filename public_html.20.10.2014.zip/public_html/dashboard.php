<html>
<head>
<link rel="stylesheet" type="text/css" href="buttons.css">
<link rel="stylesheet" type="text/css" href="form.css">
</head>
<body>
<div id="header">
</div>
<div class="navAlign" id="container">
<ul class="navButton">

<li id="current"><a href="dashboard.php">Dashboard</a></li>
<li><a href="viewEvents.php">Events</a></li>
<li><a href = "viewVolunteers.php">Volunteers</a></li>
<li><a href = "viewActivities.php">Activities</a></li>
<li><a href = "viewRoles.php">Roles</a></li>

</ul>
</div>


<div class="content" id="container">
<p id="pAlign">
Testing 123 hello
</p>

<p id="pAlign">
Testing 123 hello
</p>



<!--Send the form for processing to the newEventProcess php file-->


</div>
</body>
</html>