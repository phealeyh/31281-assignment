<?php

session_start();
if ($_SESSION['LoggedIn'] != $_SESSION['AdminCode'] && $_SESSION['LoggedIn'] !=$_SESSION['EMCode']) {
    header("Location: index.php");
}


?>
<!-- File: manageEvent.php
 * ------------------------
 * This html file contains the list of events within the system.
 * It is also responsible for establishing the connection between the database and requesting
 * queries about the list of events. It displays the events in a drop down box.
 -->
<html>
<head>

<link rel="stylesheet" type="text/css" href="buttons.css">
<link rel="stylesheet" type="text/css" href="form.css">
</head>
<body>

<div id="header">
<?php $currentUser = $_SESSION['Name']; ?>
Logged in as: <b><?php echo $currentUser; ?></b>            <a href="logout.php"> Log Out </a>
</div>

<div class="navAlign" id="container">
<?php echo $_SESSION['Navigation']; ?>

<?php 
$eID = $_POST['event_list'];
$_SESSION['ActiveEvent'] = $eID;
$_SESSION['EMRedirect'] = -1;
//Defines the constants along with its values
define('DB_NAME', 'group14x_database'); //name of database
define('DB_USER', 'group14x'); //name of database user
define('DB_PW', 'wearethebest'); //password
define('DB_HOST', 'localhost'); //where the database is running

//a variable created based on the connection to the sql database
$dbLink = mysql_connect(DB_HOST,DB_USER, DB_PW);
mysql_select_db(DB_NAME,$dbLink); 

//insert the user record into the database
$get_SQL = mysql_query("SELECT Event_ID, Name, Description, Start_Date, End_Date FROM `Event` 
 WHERE Event_ID = $eID"); 

//if (!mysql_query($get_SQL)) { //checks if there is a valid record selected; if not, execute statement
//    die('Error: ' . mysql_error());
//}

$i=0;

$row = mysql_fetch_array($get_SQL);


$gN = $row['Name'];
$gD = $row['Description'];
$gSD = $row['Start_Date'];
$gED = $row['End_Date'];


//mysql_close($dbLink); //closes the connection to the database
?>

</div>

<div class="content" id="container">
	<h2> <?php echo $gN; ?> </h2>
	<h3> Start Date: </h3> <?php echo $gSD; ?> 
	<h3> End Date: </h3> <?php echo $gED; ?> 
	<p>  <?php echo $gD; ?> </p>
	<form action="updateEventV.php?e_ID=<?php echo $eID; ?>" method="post">
        <input type="submit" value="Update">
        </form>
	
</div>


<div class="content" id="container">

<h2> Activities: </h2>

<!-- Allows a specific event to be editted -->
<form action="manageActivity.php" method="post" id="dropdown"> 
<?php

//a variable created based on the connection to the sql database
$dbLink = mysql_connect(DB_HOST,DB_USER, DB_PW);
mysql_select_db(DB_NAME,$dbLink); 
$activityQuery = "SELECT * FROM `Activities` WHERE Event_ID ='$eID' ORDER BY Name";
$activitiesList = mysql_query($activityQuery);
?>
<select id="activity_list" name="activity_list" style="width: 400px;">
<?php
$i=0;

while($row = mysql_fetch_array($activitiesList)) { //loops until the end of the volunteers list, which should return a false
?>
<!--Displays the list of  options within the html page-->
<option value=<?=$row["Activity_ID"];?>><?=$row["Name"] ;?></option>
<?php
$i++;
}

?>
</select>
<?php
mysql_close($dbLink); //closes the connection to the database
?>

<input type="submit" value="Manage"> 
</form>
<p><br><br><br><br></p>

<form action="addActivities.php?e_ID=<?php echo $eID; ?>" method="post"> <!-- Specifies where to send the form data -->
<input type="submit" value="Add New Activity"> <!--creates the add event button-->
</form>





</div>


</body>
</html>