<?php
session_start();
$_SESSION['AdminCode'] = 103;
$_SESSION['EMCode'] = 102;
$_SESSION['SproutCode'] = 101;
$_SESSION['VolunteerCode'] = 100;
$activeEvent = 0;


?>
<!-- File: manageEvent.php
 * ------------------------
 * This html file contains the list of events within the system.
 * It is also responsible for establishing the connection between the database and requesting
 * queries about the list of events. It displays the events in a drop down box.
 -->
<html>
<head>

<link rel="stylesheet" type="text/css" href="buttons.css">
<link rel="stylesheet" type="text/css" href="form.css">

<script>
function confirmReg() {
    if (confirm("Do you want to register for this activity?") == true) {
        return true;
    } else {
        return false;
    }
}

</script>

</head>
<body>
<div id="header">
<?php $currentUser = $_SESSION['Name']; ?>
<?php
if ($_SESSION['LoggedIn'] == $_SESSION['SproutCode'] || $_SESSION['LoggedIn'] ==$_SESSION['VolunteerCode']) {
    echo "Logged in as: <b>" . $currentUser . "</b>            <a href=\"logout.php\"> Log Out </a>";
} else {
    echo "Viewing as: <b>Guest</b>            <a href=\"index.php\"> Sign In</a>";
}
?>
</div>

<div class="navAlign" id="container">
<?php 
if ($_SESSION['LoggedIn'] == $_SESSION['SproutCode'] || $_SESSION['LoggedIn'] ==$_SESSION['VolunteerCode']) {
    echo $_SESSION['Navigation'];
} else {
   echo "<ul class=\"navButton\">
         <li id=\"current\"><a href=\"viewPositions.php\">Volunteer</a></li>
         </ul>";
}
?>

<?php 
$aID = $_POST['activitieslist'];

if ($aID == null || !isset($_POST['activitieslist'])) {
	$aID = $_GET['a_ID'];	
}
//Defines the constants along with its values
define('DB_NAME', 's1053775_database'); //name of database
define('DB_USER', 's1053775_root'); //name of database user
define('DB_PW', 'W3arethebest'); //password
define('DB_HOST', 'localhost'); //where the database is running

//a variable created based on the connection to the sql database
$dbLink = mysql_connect(DB_HOST,DB_USER, DB_PW);
mysql_select_db(DB_NAME,$dbLink); 

//insert the user record into the database
$get_SQL = mysql_query("SELECT * FROM `Activities` 
 WHERE Activity_ID = $aID"); 

//if (!mysql_query($get_SQL)) { //checks if there is a valid record selected; if not, execute statement
//    die('Error: ' . mysql_error());
//}

$i=0;

$row = mysql_fetch_array($get_SQL);


$gN = $row['Name'];
$gD = $row['Description'];
$gSD = $row['Start_Date'];
$gED = $row['End_Date'];
$gTSD = $row['Start_Time'];
$gTED = $row['End_Time'];
$eID = $row['Event_ID'];
$gPR = $row['PayRate'];
$gDU = $row['Duration'];
$gRQ = $row['ActivityPeopleRequired'];
$gSP = $row['SproutOnly'];

//mysql_close($dbLink); //closes the connection to the database
?>

</div>

<div class="contentBox">
<h2 id="positionTopH2"><?php echo $gN; ?></h2>

<div class="contentRectangleEvent" id="rectangleContainer">

	<pre id="preAlignH3">
	<h3>Activity Details</h3>
	</pre>
	
	<pre id="preAlign">
	Event Name: <em><?php echo $gN; ?></em>		
	Start Date: <em><?php echo $gSD; ?></em>
	End Date: <em><?php echo $gED; ?></em>
	Start Time: <em><?php echo $gTSD; ?></em> 
        End Time: <em><?php echo $gTED; ?></em> 
	Duration (Hrs): <em><?php echo $gDU; ?></em> 
	Positions Filled:<em>0/<?php echo $gRQ; ?></em>
	<?php
	if($gPR > 0)
	{
	echo "Pay Rate: <em>$" . $gPR . "</em>";
	}
	?>
	</pre>
	<p id="column">Description:</p>
	<div style="overflow-y: scroll;" class="eventDescription" id="eventDescriptionPosition">
	<p id="pAlign">
	<em><?php echo $gD; ?></em>
	</p>
</div><form action="preRegister.php?a_ID=<?php echo $aID; ?>" method="post" onsubmit="return confirmReg()"> <!-- Specifies where to send the form data -->
<input type="submit" value="Register" class="button" id="updateButtonRnE">
</form>
<form action="preRegisterUpdate.php?a_ID=<?php echo $aID; ?>" method="post"> <!-- Specifies where to send the form data -->
<input type="submit" value="Update" class="button" id="updateButtonRnE">
</form>
	</div>

</div>







	

<div class="contentRectangleActivity " id="rectangleContainer2">
	
	<pre id="preAlignH3">
	<h3>Activities</h3>
	</pre>
	<form action="addActivities.php?e_ID=<?php echo $eID; ?>" method="post"> <!-- Specifies where to send the form data -->
<input type="submit" value="Inquire" class="button" id="activityButton"> <!--creates the add event button-->
</form>
	
<form action="viewVolunteerActivityDetail.php" method="post"> 
<input type="submit" value="View Details" class="button" id="manageActivityButton"> 
<?php

//a variable created based on the connection to the sql database
$dbLink = mysql_connect(DB_HOST,DB_USER, DB_PW);
mysql_select_db(DB_NAME,$dbLink);
date_default_timezone_set('Australia/Melbourne');
$currentDate = date("Y-m-d"); 
$activityQuery = "SELECT * FROM `Activities` WHERE Event_ID ='$eID' 
AND End_Date > '$currentDate' ORDER BY Name";
$activitiesList = mysql_query($activityQuery);
?>



<?php
$i=0;
echo "<div style=\"overflow-y: scroll; overflow-x: hidden;\" class=\"activitySmall\" id=\"positionActivitySmall\"><table border='1' class=\"table1\" id='container' >
<tr>
<th>Select</th>
<th>Activity ID</th>
<th>Activity Name</th>
<th>Start Date</th>
<th>End Date</th>
</tr>";
while($row = mysql_fetch_array($activitiesList)) { //loops until the end of the volunteers list, which should return a false


  echo "<tr>";
  echo "<td><input type=\"radio\" name=\"activitieslist\" value=".$row['Activity_ID']."></td>";
  echo "<td>" . $row['Activity_ID'] . "</td>";
  echo "<td>" . $row['Name'] . "</td>";
  echo "<td>" . $row['Start_Date'] . "</td>";
  echo "<td>" . $row['End_Date'] . "</td>";
  echo "</tr>";


?>
<?php
$i++;

}

?>

<?php
mysql_close($dbLink); //closes the connection to the database
?>

</form>


</div>

</body>
</html>