<?php

session_start();
$_SESSION['AdminCode'] = 103;
$_SESSION['EMCode'] = 102;
$_SESSION['SproutCode'] = 101;
$_SESSION['VolunteerCode'] = 100;
if ($_SESSION['LoggedIn'] > 99 ){
    header("Location: viewPositions.php");
}



?>
<!-- File: manageEvent.php
 * ------------------------
 * This html file contains the list of events within the system.
 * It is also responsible for establishing the connection between the database and requesting
 * queries about the list of events. It displays the events in a drop down box.
 -->
<html>
<head>
<link rel="stylesheet" type="text/css" href="form.css">
<link rel="stylesheet" type="text/css" href="buttons.css">
<link rel="stylesheet" type="text/css" href="index.css">
</head>
<body>

<div id="header">
<?php $currentUser = $_SESSION['Name']; ?>
Logged in as: <b><?php echo $currentUser; ?></b>            <a href="logout.php"> Log Out </a>
</div>

<div class="navAlign" id="container">
<?php echo $_SESSION['Navigation']; ?>
</div>


<?php 
 
$aID = $_GET['a_ID'];	
?>

<div class="contentBoxLong3">



<h2 id="positionTopH2">Sign In: <?php echo $gN ?></h2>




<!-- ACTIVITY DETAILS HERE -->
<!-- ********************* -->
<div class="contentRectangleEvent3" id="rectangleContainer">

<form action="loginProcessA.php?a_ID=<?php echo $aID; ?>" method="post" class="login">
 <h1><span>Login with your username and password.</span></h1>
<label>
<span>Username</span>
<input id="username" type="text" name="username" placeholder="Username" />
</label>

<label>
<span>Password</span> 
<input id="password" type="password" name="password" placeholder="Password" 
</label>


<label>
<span>&nbsp</span>
<input type="submit" class="button" value="Login" />
</label>
</form>

 <h1><span><em>OR</em></span></h1>
 <form action="addUserA.php?a_ID=<?php echo $aID; ?>" method="post" class="login">
 <label>
<span>&nbsp</span>
<input type="submit" class="button" value="Sign Up" />
</label>
</form>


</div>

</body>
</html>