<?php
session_start();
//codes allocated for each user type
$_SESSION['AdminCode'] = 103;
$_SESSION['EMCode'] = 102;
$_SESSION['SproutCode'] = 101;
$_SESSION['VolunteerCode'] = 100;

if ($_SESSION['LoggedIn'] != $_SESSION['AdminCode'] && $_SESSION['LoggedIn'] !=$_SESSION['EMCode']) {
    header("Location: index.php");
}
?>

<!-- File: viewVolunteersSA.php
 * ------------------------
 * This html file contains the list of volunteers within the system.
 * It is also responsible for establishing the connection between the database and requesting
 * queries about the list of volunteers. It displays the volunteers names in a drop down box.
 -->
<html>
<head>

<link rel="stylesheet" type="text/css" href="buttons.css">
</head>
<body>

<div id="header">
<?php $currentUser = $_SESSION['Name']; ?>
Logged in as: <b><?php echo $currentUser; ?></b>            <a href="logout.php"> Log Out </a>
</div>
<div class="navAlign" id="container">
<?php echo $_SESSION['Navigation']; ?>
</div>

<div class="contentBox">

<h2 id="positionTopH2">All Users</h2>


<form action="addUserTypeProcess.php" method="post" id="bottomButton1"> <!-- Specifies where to send the form data -->
<p id="addNew">
Add New:
</p>
<select id="dropDownList" name="usertype_list" style="width: 400px, height: 50px;">
<option value="2">Manager</option>
<option value="1">Volunteer</option>
</select>

<input type="submit" value="+" id="plusSign"> <!--creates the add user button-->
</form>



<form action="updateUserTypeProcess.php" method="post"> 
<input type="submit" class="button" value="Update" id="bottomButton2"> 
<?php
//Defines the constants along with its values
define('DB_NAME', 's1053775_database'); //name of database
define('DB_USER', 's1053775_root'); //name of database user
define('DB_PW', 'W3arethebest'); //password
define('DB_HOST', 'localhost'); //where the database is running

//a variable created based on the connection to the sql database
$dbLink = mysql_connect(DB_HOST,DB_USER, DB_PW);
mysql_select_db(DB_NAME,$dbLink); 

if ($_SESSION['LoggedIn'] == $_SESSION['AdminCode']) { // if admin
	$volunteersList = mysql_query("SELECT * FROM `User Details` ORDER BY Given_Names");
} else {
	$volunteersList = mysql_query("SELECT * FROM `User Details` INNER JOIN Account ON UTS_ID = User_ID WHERE Privilege < 3 ORDER BY Given_Names");    	
}
?>

<?php
$i=0;




echo "<div style=\"overflow-y: scroll; overflow-x: hidden;\" class=\"contentSmall\" id=\"scrollBox\"><table border='1' class=\"table1\" id='container' >
<tr>
<th>Select</th>
<th>User ID</th>
<th>Given Name</th>
<th>Surname</th>
<th>Email</th>
</tr>";





while($row = mysql_fetch_array($volunteersList)) { //loops until the end of the volunteers list, which should return a false

  echo "<tr>";
  echo "<td><input type=\"radio\" name=\"volunteer_list\" value=".$row['User_ID']."></td>";
  echo "<td>" . $row['User_ID'] . "</td>";
  echo "<td>" . $row['Given_Names'] . "</td>";
  echo "<td>" . $row['Surname'] . "</td>";
  echo "<td>" . $row['Primary_Email'] . "</td>";
  echo "</tr>";



?>
<?php
$i++;
}


?>

<?php
mysql_close($dbLink); //closes the connection to the database
?>
</div>

</form>


</div>

</body>
</html>